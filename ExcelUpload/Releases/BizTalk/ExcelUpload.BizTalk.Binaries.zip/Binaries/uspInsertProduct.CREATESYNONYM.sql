USE [AdventureWorks]
GO

CREATE SYNONYM uspInsertProduct 
FOR [Production].[uspInsertProduct]
GO;