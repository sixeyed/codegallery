using System;
using System.Collections.Generic;
using System.Text;

namespace FluentDAL.Sample.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class Address
    {
        public string Line1 { get; set; }

        public PostCode PostCode { get; set; }
    }
}
