﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DynamicSP.Sample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sixeyed Consulting")]
[assembly: AssemblyProduct("DynamicSP.Sample")]
[assembly: AssemblyCopyright("Copyright © Sixeyed Consulting 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("73BD4BD6-75FB-4B83-A28C-8311A7A4EA53")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]