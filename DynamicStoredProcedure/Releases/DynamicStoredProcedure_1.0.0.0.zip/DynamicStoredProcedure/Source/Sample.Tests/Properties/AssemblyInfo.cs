﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DynamicSP.Sample.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sixeyed Consulting")]
[assembly: AssemblyProduct("DynamicSP.Sample.Tests")]
[assembly: AssemblyCopyright("Copyright © Sixeyed Consulting 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("621a76d9-3d9d-4e49-8997-c52e36f845bf")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
