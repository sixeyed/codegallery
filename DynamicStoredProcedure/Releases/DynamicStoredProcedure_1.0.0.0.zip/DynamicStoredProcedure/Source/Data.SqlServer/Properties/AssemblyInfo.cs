﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DynamicSP.Data.SqlServer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sixeyed Consulting")]
[assembly: AssemblyProduct("DynamicSP.Data.SqlServer")]
[assembly: AssemblyCopyright("Copyright © Sixeyed Consulting 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("1A684DCB-0482-44AF-8154-204EBF6C8358")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]