﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Sixeyed.OptimisticLockingSample.ServiceModel.FaultDetail
{
    [DataContract(Namespace = "http://Sixeyed.OptimisticLockingSample/2009")]
    public class ConcurrencyViolation
    {
    }
}
