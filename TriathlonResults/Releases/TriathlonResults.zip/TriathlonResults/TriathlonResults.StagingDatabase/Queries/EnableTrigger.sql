
USE TriathlonStaging
GO

ENABLE TRIGGER [dbo].[ProcessSectorTime]
ON [dbo].SectorTimes; 