
USE TriathlonStaging
GO

DELETE SectorTimes;