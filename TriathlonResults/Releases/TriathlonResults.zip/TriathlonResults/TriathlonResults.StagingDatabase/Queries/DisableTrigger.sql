
USE TriathlonStaging
GO

DISABLE TRIGGER [dbo].[ProcessSectorTime] 
ON [dbo].SectorTimes; 