
The entity and service request classes were generated from the 
"ESB Simple Samples Service Client Generator", pointing at the WSDL
for the Central Web service.

Then modified to use the  entity class & add Guids & interfaces for COM interop.

See http://www.codeplex.com/ESBSimpleSamples

CCW for Excel created first from: 

regasm triathlonresults.central.servicerequests.dll /tlb TriathlonResults.Central.ServiceRequests.tlb /codebase

- automated in SetupPhase2.cmd