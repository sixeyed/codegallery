
This solution contains a set of systems demonstrating approaches for 
migrating bespoke system integrations to SOA using ESB Guidance 1.0.

It is available from the MSDN Code Gallery: 

	http://code.msdn.microsoft.com/ESBTriathlonResults

Details on the following blog post: 

	http://geekswithblogs.net/EltonStoneman/archive/2008/10/25/esb-guidance-demonstration-triathlonresults.aspx